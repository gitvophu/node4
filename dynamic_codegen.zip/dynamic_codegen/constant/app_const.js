
module.exports.APP_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9k7INCN_gkvzJUlfo";

